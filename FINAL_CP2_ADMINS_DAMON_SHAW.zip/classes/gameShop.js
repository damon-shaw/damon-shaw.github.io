function GameShop() {
    this.createBomberProb = 0.01;
}