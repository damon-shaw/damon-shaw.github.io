function ComboDisplay(xPos, yPos, comboValue) {
    
}