var COLORS = {
    skyBlue: "#badbdb",
    evilGrey: "#2b2b2b",
    translucentWhite: "#ebebebdd",
    highPeakGrey: "#79777E",
    oliveGreen: "#597d35",
    sageGreen: "#728c67",
    seaweedGreen: "#3E5725",
    armyGreen: "#51673A",
    dirt: "#583922",
    fadedBlack: "#00000080"
};