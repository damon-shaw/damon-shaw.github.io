var COLORS = {
    skyBlue: "#badbdb",
    evilGrey: "#2b2b2b",
    slateGrey: "#708090",
    bloodRed: "#a10c02",
    scarletRed: "#d43722",
    translucentWhite: "#ebebebdd",
    highPeakGrey: "#79777E",
    oliveGreen: "#597d35",
    sageGreen: "#728c67",
    seaweedGreen: "#3E5725",
    armyGreen: "#51673A",
    dirt: "#583922",
    fadedBlack: "#00000080",
    laserGreen: "#00d142",
    schoolBusYellow: "#fcba03"
};