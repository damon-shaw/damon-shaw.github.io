function GameShop() {
    this.createBomberProb = 0.009;
    this.createSeekerProb = 0.004;
}